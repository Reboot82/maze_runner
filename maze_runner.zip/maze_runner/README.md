# maze-runner
Java command line game where players navigate through a maze. Project for module 4 of the edX course, "Learn to Program in Java".
